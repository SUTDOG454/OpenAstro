from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/ubuntu/openastro_worktree')
OUT = ROOT / 'data/research'
OUT.mkdir(parents=True, exist_ok=True)

master = json.loads((ROOT / 'data/unified/unified_astrology_master.json').read_text())
latest = json.loads((ROOT / 'data/unified/latest_afe_integration.json').read_text())
indicator_data = json.loads((ROOT / 'data/interpretation-indicators/normalized_interpretation_indicators.json').read_text())

all_records = indicator_data['records']
research_records = []
for record in latest['records_by_type'].get('indicator_definition', []):
    value = record.get('normalized_value', {})
    text = json.dumps(value, ensure_ascii=False)
    category = 'economic_indicator' if re.search(r'economic|macro|yield|inflation|gdp|cpi|vix|treasury|commodity|exchange|unemployment', text, re.I) else 'company_financial_indicator'
    research_records.append({
        'record_id': record['record_id'], 'category': category, 'source_ids': record.get('source_ids', []),
        'raw_value': record.get('raw_value'), 'normalized_value': value, 'status': 'source_derived',
        'evidence_class': 'source_derived', 'prohibited_uses': ['trading instructions', 'position sizing', 'personal financial advice'],
    })

# Build method records from existing named methods and explicit strategy-like source text.
method_records = [
    {'method_id': 'walk_forward_time_split', 'category': 'training_testing_method', 'definition': 'Evaluate temporal rows using expanding or rolling training windows and future validation windows.', 'status': 'methodology_bound', 'source': 'unified_master.research_contract', 'leakage_controls': ['feature cutoff', 'outcome after cutoff', 'no holdout tuning']},
    {'method_id': 'purged_time_split', 'category': 'training_testing_method', 'definition': 'Remove observations that overlap a validation outcome window before evaluating a temporal model.', 'status': 'methodology_bound', 'source': 'unified_master.research_contract', 'leakage_controls': ['purge overlapping observations', 'feature cutoff']},
    {'method_id': 'buy_and_hold_baseline', 'category': 'baseline', 'definition': 'Compare any exploratory market association against a naive market baseline.', 'status': 'methodology_bound', 'source': 'unified_master.research_contract', 'prohibited_uses': ['trading instructions']},
    {'method_id': 'regime_sensitivity', 'category': 'robustness_method', 'definition': 'Report whether an exploratory association changes across explicitly defined market regimes.', 'status': 'methodology_bound', 'source': 'unified_master.research_contract', 'requires': ['regime definition', 'sample size per regime', 'negative results']},
    {'method_id': 'sentiment_as_feature_family', 'category': 'market_sentiment', 'definition': 'Treat news, recommendations, holders, and other sentiment proxies as timestamped features with source and availability metadata.', 'status': 'pending_review', 'source': 'unified_master.research_contract', 'requires': ['source license', 'available_at', 'feature cutoff', 'missingness policy']},
]

strategy_records = []
for record in all_records:
    text = record.get('normalized_text', '')
    if re.search(r'strategy|method|approach|protocol|framework|baseline|validation|backtest|testing', text, re.I):
        strategy_records.append({
            'record_id': record['indicator_id'], 'category': 'source_strategy_or_method_text', 'subject_path': record['subject_path'],
            'text': record['normalized_text'], 'keywords': record.get('keywords', []), 'source_ids': record.get('source_ids', [record['source_id']]),
            'status': 'source_derived', 'evidence_class': 'source_derived', 'prohibited_uses': ['treating prose as validated performance'],
        })

research_manifest = {
    'schema_version': '1.0.0', 'dataset_id': 'openastro_research_methods_and_indicator_definitions',
    'status': 'configuration_and_method_records_only', 'generated_at': datetime.now(timezone.utc).isoformat(),
    'source_refs': ['data/unified/unified_astrology_master.json', 'data/unified/latest_afe_integration.json', 'data/interpretation-indicators/normalized_interpretation_indicators.json'],
    'observations_acquired': False, 'labels_acquired': False,
    'feature_cutoff_rule': master['research_contract']['financial_astrology']['feature_cutoff_rule'],
    'split_strategy': master['research_contract']['financial_astrology']['split_strategy'],
    'baseline_requirements': master['research_contract']['financial_astrology']['baseline_requirements'],
    'uncertainty_requirements': master['research_contract']['financial_astrology']['uncertainty'],
    'prohibited_uses': master['research_contract']['financial_astrology']['prohibited_uses'],
    'missingness_policy': 'record missing values explicitly; do not impute without a declared method',
    'source_rights': 'pending_review',
}

(OUT / 'economic_indicators.json').write_text(json.dumps({'schema_version': '1.0.0', 'records': research_records}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'training_testing_methods.json').write_text(json.dumps({'schema_version': '1.0.0', 'records': method_records}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'market_sentiment_and_strategies.json').write_text(json.dumps({'schema_version': '1.0.0', 'records': strategy_records}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'research_dataset_manifest.json').write_text(json.dumps(research_manifest, ensure_ascii=False, indent=2) + '\n')
(OUT / 'research_layer_summary.json').write_text(json.dumps({'schema_version': '1.0.0', 'economic_indicator_count': len(research_records), 'method_count': len(method_records), 'strategy_or_sentiment_text_count': len(strategy_records), 'observations_acquired': False, 'status': research_manifest['status'], 'limitations': ['No new market API calls or synthetic observations were used.', 'These records define features and methods, not validated strategies or forecasts.']}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'economic_indicators': len(research_records), 'methods': len(method_records), 'strategy_or_sentiment_text': len(strategy_records)}, indent=2))
