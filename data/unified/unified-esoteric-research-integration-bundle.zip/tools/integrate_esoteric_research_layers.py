from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/ubuntu/openastro_worktree')
master_path = ROOT / 'data/unified/unified_astrology_master.json'
master = json.loads(master_path.read_text())
summary = json.loads((ROOT / 'data/research/research_layer_summary.json').read_text())

master['status'] = 'expanded_with_isolated_esoteric_and_research_layer'
master['esoteric_retrieval_namespace'] = {
    'status': 'isolated_source_retrieval',
    'tradition_mode': 'esoteric',
    'typescript_module': 'client/src/lib/astro/delineation/esotericNamespace.ts',
    'corpus_loader': 'client/src/lib/astro/delineation/esotericCorpus.ts',
    'calculation_engine': 'none',
    'allowed_engine': 'esoteric_retrieval_only',
    'rejected_modes': ['western', 'vedic', 'standard'],
    'source_refs': ['data/interpretation-indicators/normalized_interpretation_indicators.json', 'gw4yP30qoqPeIhTA3L9cO0'],
    'policy': 'Esoteric records are retrieved only when tradition_mode is explicitly esoteric and are never injected into standard Western or Vedic calculation engines.',
}
master['research_layer'] = {
    'status': summary['status'],
    'economic_indicators_ref': 'data/research/economic_indicators.json',
    'training_testing_methods_ref': 'data/research/training_testing_methods.json',
    'market_sentiment_and_strategies_ref': 'data/research/market_sentiment_and_strategies.json',
    'manifest_ref': 'data/research/research_dataset_manifest.json',
    'summary_ref': 'data/research/research_layer_summary.json',
    'counts': {
        'economic_indicators': summary['economic_indicator_count'],
        'training_testing_methods': summary['method_count'],
        'strategy_or_sentiment_text': summary['strategy_or_sentiment_text_count'],
    },
    'observations_acquired': False,
    'labels_acquired': False,
    'policy': 'Configuration and methodology records only; no synthetic observations, validated strategy performance, or financial advice.',
}
master.setdefault('implementation_notes', {})['esoteric_namespace_isolation'] = 'TypeScript retrieval-only namespace; no Western, Vedic, or standard calculation engine calls.'
master['implementation_notes']['research_layer'] = 'Timestamped feature definitions and methodology contracts are linked under data/research; feature cutoffs are validated by client/src/lib/astro/research/featureCutoff.ts.'
master['generated_at'] = datetime.now(timezone.utc).isoformat()
master_path.write_text(json.dumps(master, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': master['status'], 'research_counts': master['research_layer']['counts']}, indent=2))
