export type StatementType = 'income' | 'balance' | 'cashflow' | (string & {});
export type StatementFrequency = 'annual' | 'quarterly' | 'trailing' | (string & {});

export interface FinancialStatementMappingOptions {
  symbol: string;
  statementType: StatementType;
  frequency: StatementFrequency;
  providerId?: string | null;
}

export interface ProviderNeutralFinancialStatement {
  symbol: string;
  statementType: string;
  frequency: string;
  statement: Record<string, Record<string, number>>;
  providerId?: string | null;
}

export class FinancialStatementParseError extends Error {
  readonly code:
  | 'INVALID_RESPONSE'
  | 'EMPTY_RESULT'
  | 'NO_USABLE_DATA';
  readonly symbol: string;

  constructor(code: FinancialStatementParseError['code'], symbol: string, message: string) {
    super(message);
    this.name = 'FinancialStatementParseError';
    this.code = code;
    this.symbol = symbol;
  }
}

interface RawTimeseriesResult {
  meta?: { type?: unknown };
  [key: string]: unknown;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function asObjectArray(value: unknown): Record<string, unknown>[] {
  return Array.isArray(value) ? value.filter(isRecord) : [];
}

/** Remove provider frequency prefixes while retaining the provider metric name. */
export function stripFrequencyPrefix(name: string): string {
  for (const prefix of ['annual', 'quarterly', 'trailing']) {
    if (name.startsWith(prefix)) return name.slice(prefix.length);
  }
  return name;
}

/** Extract Yahoo/FMP-compatible numeric values from a reported-value object. */
export function extractReportedValue(reportedValue: unknown): number | undefined {
  if (!isRecord(reportedValue)) return undefined;

  const raw = reportedValue.raw;
  if (typeof raw === 'number' && Number.isFinite(raw)) return raw;

  if (isRecord(raw)) {
    const parsedValue = raw.parsedValue;
    if (typeof parsedValue === 'number' && Number.isFinite(parsedValue)) return parsedValue;
  }

  return undefined;
}

function readMetricName(result: RawTimeseriesResult): string {
  const meta = isRecord(result.meta) ? result.meta : undefined;
  const types = meta?.type;
  return Array.isArray(types) && typeof types[0] === 'string' ? types[0] : '';
}

/**
 * Convert a Yahoo-style fundamentals-timeseries payload into a provider-neutral statement.
 * The source payload is preserved by the caller; this function only returns normalized values.
 */
export function mapProviderNeutralFinancialStatement(
  raw: unknown,
  options: FinancialStatementMappingOptions,
): ProviderNeutralFinancialStatement {
  const symbol = options.symbol.trim();
  if (!isRecord(raw) || !isRecord(raw.timeseries) || !Array.isArray(raw.timeseries.result)) {
    throw new FinancialStatementParseError(
      'INVALID_RESPONSE',
      symbol,
      'Financial statement response must contain timeseries.result[]',
    );
  }

  const results = asObjectArray(raw.timeseries.result);
  if (results.length === 0) {
    throw new FinancialStatementParseError(
      'EMPTY_RESULT',
      symbol,
      `No ${options.frequency} ${options.statementType} data found`,
    );
  }

  const statement: Record<string, Record<string, number>> = {};

  for (const result of results) {
    const providerMetricName = readMetricName(result);
    if (!providerMetricName) continue;

    const metricName = stripFrequencyPrefix(providerMetricName);
    const dataPoints = asObjectArray(result[providerMetricName]);
    if (dataPoints.length === 0) continue;

    const dateValues: Record<string, number> = {};
    for (const point of dataPoints) {
      const asOfDate = typeof point.asOfDate === 'string' ? point.asOfDate : '';
      if (!asOfDate) continue;

      const value = extractReportedValue(point.reportedValue);
      if (value !== undefined) dateValues[asOfDate] = value;
    }

    if (Object.keys(dateValues).length > 0) statement[metricName] = dateValues;
  }

  if (Object.keys(statement).length === 0) {
    throw new FinancialStatementParseError(
      'NO_USABLE_DATA',
      symbol,
      `No ${options.frequency} ${options.statementType} data found`,
    );
  }

  return {
    symbol: symbol.toUpperCase(),
    statementType: options.statementType,
    frequency: options.frequency,
    statement,
    providerId: options.providerId ?? null,
  };
}

export const parseFinancialStatement = mapProviderNeutralFinancialStatement;

export function parseFinancialStatementJson(
  json: string,
  options: FinancialStatementMappingOptions,
): ProviderNeutralFinancialStatement {
  let raw: unknown;
  try {
    raw = JSON.parse(json);
  } catch (error) {
    throw new FinancialStatementParseError(
      'INVALID_RESPONSE',
      options.symbol.trim(),
      `Invalid financial statement JSON: ${error instanceof Error ? error.message : String(error)}`,
    );
  }

  return mapProviderNeutralFinancialStatement(raw, options);
}
